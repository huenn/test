//: Playground - noun: a place where people can play
import Cocoa
//1. Cho 2 loai hinh: hinh tron (o,r), hinh chu nhat(c,w,h)
// + PT: Tinh chu vi
// + PT: Tinh dien tich
// + PT: in thong tin
// Tao 1 mang cac loai hinh: 5 hinh: tron + vuong
// a. In ra thong tin cua tat ca cac hinh co trong mang
// b. Deep coppy mang

class Hinh {
    
    func dienTich() -> Double
    {
        return 0
    }
    
    func chuVi() -> Double {
        return 0
    }
    func show(cv: Double, dt: Double) {
        print("- Chu vi la: \(cv)")
        print("  Dien tich la: \(dt)")
    }
    func clone() -> Hinh{
        return Hinh()
    }
}

struct DiemXY {
    var x: Int32
    var y: Int32
}

class HinhTron: Hinh {
    var diem: DiemXY
    var r: Double
    
    init (diem: DiemXY, r: Double){
        self.diem = diem
        self.r = r
    }
    
    override func dienTich() -> Double {
        return r*r * 3.14
    }
    
    override func chuVi() -> Double {
        return r * 2 * 3.14
    }
    
}

class HinhChuNhat: Hinh {
    var diem: DiemXY
    var w: Double
    var h: Double
    
    init (diem: DiemXY, w: Double, h: Double) {
        self.diem = diem
        self.w = w
        self.h = h
    }
    
    override func dienTich() -> Double {
        return w*h
    }
    
    override func chuVi() ->Double{
        return (w+h)*2
    }
    
}


var a : Int = 9
var arrays : [Int] = [1, 2, 3]
var arrays1 = [1, 2, 3]
var arrhinh : [Hinh]=[]
let diem = DiemXY(x:3,y:4)
var hinhtron1 = HinhTron(diem: diem, r: 5)
arrhinh.append(HinhTron(diem:diem,r: 7))
arrhinh.append(HinhTron(diem:diem,r: 9))
arrhinh.append(HinhChuNhat(diem:diem, w:3,h:4))
arrhinh.append(HinhChuNhat(diem:diem,w: 8, h: 10))
arrhinh.append(HinhChuNhat(diem:diem,w: 5, h: 15))

for i in 0...arrhinh.count - 1 {
    arrhinh[i].show(cv: arrhinh[i].chuVi(), dt: arrhinh[i].dienTich())
}

var anotherarrhinh = arrhinh
print ("test")

